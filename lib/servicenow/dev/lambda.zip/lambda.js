const https = require('https');
const AWS = require('aws-sdk');

AWS.config.update({
  region: process.env.AWS_REGION
});

const snConnectAPI = {
  processEvent: (debugCtx, settings, inputs, responseHandler) => {
    const connectApiCtx = {};
    debugCtx.snConnectApi = connectApiCtx;
    const post_data = JSON.stringify(inputs);
    const authString = Buffer.from(settings.service_account_user + ':' + settings.service_account_password).toString(
      'base64'
    );

    const event = inputs.event;
    const eventDetailParameters =
      event && event.Details && event.Details.Parameters ? event && event.Details && event.Details.Parameters : {};
    const component = eventDetailParameters.sn_component
      ? eventDetailParameters.sn_component
      : 'sn_aws_connect_lex_intent_processor_component';
    const componentVersion = eventDetailParameters.sn_componentVersion
      ? eventDetailParameters.sn_componentVersion
      : 'v1.0';

    const post_options = {
      host: settings.host,
      path:
        '/api/sn_cti_core/cti_api/providers/' +
        settings.provider_id +
        '/components/' +
        component +
        '/versions/' +
        componentVersion,
      method: 'POST',
      headers: {
        'Authorization': 'Basic ' + authString,
        'Accept': 'application/json',
        'Content-Type': 'application/json;charset=UTF-8',
        'Content-Length': post_data.length
      }
    };

    const post_request = https.request(post_options, function (httpResponse) {
      let body = '';
      httpResponse.setEncoding('utf8');
      httpResponse.on('data', function (chunk) {
        body += chunk;
      });
      const commonResponseProcessing = function (codePath, httpResponse, responseHandler, e) {
        const responseContainer = {};
        responseContainer.statusCode = httpResponse.statusCode;
        responseContainer.headers = httpResponse.headers;
        try {
          responseContainer.body = JSON.parse(body);
        } catch (jpe) {
          responseContainer.body = body;
        }

        responseContainer.debug = {};
        responseContainer.debug.attributes = {};
        responseContainer.debug.attributes.sn_host = post_options.host;
        responseContainer.debug.attributes.sn_api = post_options.path;
        const error = responseContainer.error;
        if (error) {
          responseContainer.debug.attributes.sn_err = error;
        }
        if (e) {
          responseContainer.debug.attributes.error = e;
        }
        connectApiCtx.response = responseContainer;
        try {
          responseHandler(responseContainer);
        } catch (rhe) {
          debugCtx.setError(rhe);
        }
      };
      httpResponse.on('end', () => {
        commonResponseProcessing('onEnd', httpResponse, responseHandler);
      });

      httpResponse.on('error', e => {
        commonResponseProcessing('onError', httpResponse, responseHandler, e);
      });
    });

    connectApiCtx.httpRequest = {
      options: post_options,
      data: inputs
    };
    post_request.write(post_data);
    post_request.end();
  }
};
const snS3EventProxyAPI = {
  processEvent: (debugCtx, settings, context, event, handler) => {
    if (event.Records) {
      const s3 = new AWS.S3({
        apiVersion: '2006-03-01'
      });
      var promises = [];
      var recordWrappers = [];
      for (let i in event.Records) {
        const record = event.Records[i];
        const recordWrapper = {
          record: record
        };
        recordWrappers.push(recordWrapper);
        const bucket = record.s3.bucket.name;
        const key = decodeURIComponent(record.s3.object.key.replace(/\+/g, ' '));
        const params = {
          Bucket: bucket,
          Key: key
        };
        const localCtx = {};
        debugCtx.snS3EventProxyAPI = {
          processEvent: localCtx
        };
        let operation = 'headObject';
        if (handler && handler.isFetchData && handler.isFetchData(record)) {
          operation = 'getObject';
        }
        recordWrapper.record.s3operation = operation;
        const promise = s3[operation](params, (err, data) => {
          if (err) {
            const message =
              'Error getting object ' +
              key +
              ' from bucket ' +
              bucket +
              '. Make sure they exist and your bucket is in the same region as this function.';
            debugCtx.setError(err);
            recordWrapper.error = err;
            if (handler && handler.onFetchError) {
              handler.onFetchError(err, message);
            }
          } else {
            recordWrapper.data = data;
            if (handler && handler.onFetchSuccess) {
              handler.onFetchSuccess(recordWrapper.record, data);
            }
          }
        }).promise();
        promises.push(promise);
      }
      Promise.all(promises)
        .then(() => {
          for (let ri in recordWrappers) {
            const wrapper = recordWrappers[ri];
            if (wrapper.error) {
              wrapper.record.error = wrapper.error;
            }
            if (wrapper.data) {
              for (const ck in wrapper.data) {
                if ('Body' !== ck) {
                  wrapper.record.s3.object[ck] = wrapper.data[ck];
                }
              }
            }
          }
          event.Details = event.Details ? event.Details : {};
          event.Details.Parameters = event.Details.Parameters ? event.Details.Parameters : {};
          event.Details.Parameters.sn_component = 'sn_aws_connect_lambda_proxy_component';
          event.Details.Parameters.sn_componentVersion = 'v1.0';
          event.Details.Parameters['sn_operation'] = '$connect.s3.event';
          event.Details.Parameters['records'] = event.Records;
          delete event.Records;
          const responseHandler = createDefaultResponseHandler(debugCtx, (msg, data) => {});
          const request = {
            context: context,
            event: event
          };
          snConnectAPI.processEvent(debugCtx, settings, request, responseHandler);
        })
        .catch(console.error.bind(console));
    }
  }
};
const snKinesisEventProxyAPI = {
  processEvent: (debugCtx, settings, context, event) => {
    if (event.Records) {
      event.Details = event.Details ? event.Details : {};
      event.Details.Parameters = event.Details.Parameters ? event.Details.Parameters : {};
      event.Details.Parameters.sn_component = 'sn_aws_connect_lambda_proxy_component';
      event.Details.Parameters.sn_componentVersion = 'v1.0';
      event.Details.Parameters['sn_operation'] = '$connect.kinesis.event';
      event.Details.Parameters['records'] = event.Records;
      delete event.Records;
      const responseHandler = createDefaultResponseHandler(debugCtx, (msg, data) => {});
      const request = {
        context: context,
        event: event
      };
      snConnectAPI.processEvent(debugCtx, settings, request, responseHandler);
    }
  }
};

const createDefaultResponseHandler = function (debugCtx, callback) {
  return response => {
    const returnData = response.body.result;
    try {
      callback(null, returnData);
    } catch (e) {
      debugCtx.setError(e);
    } finally {
      debugCtx.log();
    }
  };
};

function processEvent(settings, event, context, callback) {
  if (event) {
    const debugOn = settings && settings.debugProxy ? 'true' === settings.debugProxy : false;
    const debugCtx = {
      inputs: {
        context: context,
        event: event
      },
      logLvl: 'info',
      setError: function (e) {
        if (e) {
          this.error = e;
        }
        this.logLvl = 'error';
      },
      log: function () {
        if (debugOn) {
          console[this.logLvl](JSON.stringify(this));
        }
      }
    };
    try {
      const firstRecord = event.Records && event.Records[0] ? event.Records[0] : null;
      if (firstRecord && 'aws:s3' === firstRecord.eventSource) {
        const handler = {
          isFetchData: function (record) {
            if (record && record.s3 && record.s3.object) {
              if (record.s3.object.key.endsWith('.json')) {
                return true;
              }
            }
            return false;
          },
          onFetchSuccess: function (record, data) {
            if (data.Body) {
              record.s3.content = data.Body.toString();
            }
          }
        };
        snS3EventProxyAPI.processEvent(debugCtx, settings, context, event, handler);
      } else if (firstRecord && 'aws:kinesis' === firstRecord.eventSource) {
        snKinesisEventProxyAPI.processEvent(debugCtx, settings, context, event);
      } else {
        const responseHandler = createDefaultResponseHandler(debugCtx, callback);
        const request = {
          context: context,
          event: event
        };
        snConnectAPI.processEvent(debugCtx, settings, request, responseHandler);
      }
    } catch (e) {
      debugCtx.setError(e);
      callback(e.message);
    } finally {
      debugCtx.log();
    }
  }
}

async function execute4Configuration(path, callback) {
  const ssm = new AWS.SSM();
  const conf = {};
  const populate = function (parameter) {
    var name = parameter.Name.substring(path.length + 1);
    conf[name] = parameter.Value;
  };
  const params = {
    Path: path,
    Recursive: true,
    WithDecryption: true
  };
  let response = await ssm.getParametersByPath(params).promise();
  response.Parameters.forEach(populate);
  while (response.NextToken) {
    params['NextToken'] = response.NextToken;
    response = await ssm.getParametersByPath(params).promise();
    response.Parameters.forEach(populate);
  }
  callback(conf);
}

exports.handler = (event, context, next) => {
  const confPath = process.env.ssm_configuration_path;
  const executeFunction = function (conf) {
    const settings = {};
    // Copy in configuration
    if (conf) {
      for (const ck in conf) {
        settings[ck] = conf[ck];
      }
    }
    // Override with local
    for (const pk in process.env) {
      settings[pk] = process.env[pk];
    }

    const requiredParams = {
      host: {
        description: 'Host name of the ServiceNow instance'
      },
      service_account_user: {
        description: 'Service account username to use when using CTI API rest endpoint'
      },
      service_account_password: {
        description: 'Service account password to use when using CTI API rest endpoint'
      },
      provider_id: {
        description: 'The provider id that will handle this request via CTI API'
      }
    };
    const missing = [];
    for (const rpk in requiredParams) {
      if (!settings[rpk]) {
        missing.push({
          name: rpk,
          description: requiredParams[rpk].description
        });
      }
    }
    if (missing.length > 0) {
      throw new Error('Missing configuration (basePath:' + confPath + '):\n' + JSON.stringify(missing));
    }

    processEvent(settings, event, context, next);
  };
  execute4Configuration(confPath, executeFunction);
};

///com.servicenow.cti/8c0c09749bea07c8a4e16b8af359ff42/TMOIY/default/service_account_user
///com.servicenow.cti/8c0c09749bea07c8a4e16b8af359ff42/TMOIY/default/service_account_password

